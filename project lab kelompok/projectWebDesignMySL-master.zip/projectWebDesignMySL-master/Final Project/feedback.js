var name = document.getElementById('name').value
var email = document.getElementById('email').value
var validEmail = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/
var buttonSubmit = document.getElementById('button')

buttonSubmit.addEventListener('click',(e)=>{
    if ( name.length < 5 || name.length > 25) {
        alert("Min name 5..25 characters")
        e.preventDefault()
    } else if ( !email.match(validEmail) ) {
        alert("Missleading input format")
        e.preventDefault()
    } else {
        alert("Thank you for the feedback 😊")
        return true
    }
},false)
   


