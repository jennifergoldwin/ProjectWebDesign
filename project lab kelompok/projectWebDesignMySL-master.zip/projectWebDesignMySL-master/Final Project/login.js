var form = document.getElementById('forms');
var submitButton = document.getElementById('button');
var nomorSL = document.getElementById("noSL").value;
var password = document.getElementById("password").value;

submitButton.addEventListener('click',(e)=>{
    if ((nomorSL.startsWith("0878") && nomorSL.length == 12)) {
        alert("Input Sesuai Kriteria")
        localStorage.setItem("slnilai",nomorSL);
        return true
    } else if ((password.length > 5  && password.length < 25)) {
        alert("Constaraint Password Accepted")
    } else {
        alert("Tidak Sesuai")
        e.preventDefault()
    }
},false)